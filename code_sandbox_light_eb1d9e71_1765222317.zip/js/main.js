/**
 * AYOZY GRAPHICS VIBES - AI CREATIVE STUDIO
 * Main JavaScript File
 * Owner: Rasheed Atayomide (rasheedatayomide914@gmail.com)
 * WhatsApp: https://wa.me/2349131103329
 */

// ========== GLOBAL STATE ========== //
const AppState = {
    currentProject: null,
    designs: [],
    animations: [],
    videos: [],
    user: {
        name: '',
        email: ''
    }
};

// ========== INITIALIZATION ========== //
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
    initializeNavigation();
    initializeChatbot();
    initializeScrollEffects();
    loadFromLocalStorage();
});

function initializeApp() {
    console.log('🎨 Ayozy Graphics Vibes - AI Creative Studio Initialized');
    console.log('👑 Owner: Rasheed Atayomide');
    
    // Add smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ========== NAVIGATION ========== //
function initializeNavigation() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    const header = document.querySelector('.main-header');
    
    // Mobile menu toggle
    if (mobileToggle && mainNav) {
        mobileToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
            const icon = mobileToggle.querySelector('i');
            if (icon) {
                icon.className = mainNav.classList.contains('active') ? 
                    'fas fa-times' : 'fas fa-bars';
            }
        });
        
        // Close mobile menu when clicking a link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                mainNav.classList.remove('active');
                const icon = mobileToggle.querySelector('i');
                if (icon) icon.className = 'fas fa-bars';
            });
        });
    }
    
    // Header scroll effect
    window.addEventListener('scroll', () => {
        if (header) {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    });
}

// ========== SCROLL EFFECTS ========== //
function initializeScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.card, .tool-button, .gallery-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
}

// ========== CHATBOT ========== //
function initializeChatbot() {
    const chatbotToggle = document.querySelector('.chatbot-toggle');
    const chatbotWindow = document.querySelector('.chatbot-window');
    const chatbotClose = document.querySelector('.chatbot-close');
    const chatbotSend = document.querySelector('.chatbot-send');
    const chatbotInput = document.querySelector('.chatbot-input');
    const chatbotMessages = document.querySelector('.chatbot-messages');
    
    if (chatbotToggle && chatbotWindow) {
        chatbotToggle.addEventListener('click', () => {
            chatbotWindow.classList.toggle('active');
        });
    }
    
    if (chatbotClose) {
        chatbotClose.addEventListener('click', () => {
            chatbotWindow.classList.remove('active');
        });
    }
    
    if (chatbotSend && chatbotInput && chatbotMessages) {
        const sendMessage = () => {
            const message = chatbotInput.value.trim();
            if (message) {
                addChatMessage(message, 'user');
                chatbotInput.value = '';
                
                // Simulate AI response
                setTimeout(() => {
                    const response = generateChatbotResponse(message);
                    addChatMessage(response, 'bot');
                }, 1000);
            }
        };
        
        chatbotSend.addEventListener('click', sendMessage);
        chatbotInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
    }
}

function addChatMessage(message, sender) {
    const chatbotMessages = document.querySelector('.chatbot-messages');
    if (!chatbotMessages) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message chat-message-${sender}`;
    messageDiv.style.cssText = `
        margin-bottom: 1rem;
        padding: 0.75rem 1rem;
        border-radius: 12px;
        max-width: 80%;
        ${sender === 'user' ? 
            'background: linear-gradient(135deg, #FF6B9D, #C44569); color: white; margin-left: auto;' :
            'background: #f5f5f5; color: #333;'}
    `;
    messageDiv.textContent = message;
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function generateChatbotResponse(message) {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('design') || lowerMessage.includes('logo') || lowerMessage.includes('flyer')) {
        return '🎨 I can help you with design! Try our AI Design Lab to create logos, flyers, and more. What would you like to design?';
    } else if (lowerMessage.includes('animation') || lowerMessage.includes('animate')) {
        return '🎬 Check out our AI Animation Studio! Just type a prompt like "animate a spinning logo" and watch the magic happen!';
    } else if (lowerMessage.includes('video')) {
        return '📽️ Our AI Video Creator can turn your ideas into stunning videos! You can also download videos from social media using our Video Downloader.';
    } else if (lowerMessage.includes('download')) {
        return '📥 You can download videos from YouTube, TikTok, Instagram, Facebook, and more! Just paste the link in our Video Downloader.';
    } else if (lowerMessage.includes('contact') || lowerMessage.includes('owner') || lowerMessage.includes('help')) {
        return `👑 Need personal assistance? Contact Rasheed Atayomide:\n📧 rasheedatayomide914@gmail.com\n📱 WhatsApp: wa.me/2349131103329`;
    } else if (lowerMessage.includes('price') || lowerMessage.includes('cost')) {
        return '💰 For pricing information, please contact the owner directly via WhatsApp or email. We offer competitive rates for all services!';
    } else {
        return '✨ Welcome to Ayozy Graphics Vibes! I can help you with designs, animations, videos, downloads, and more. What can I help you create today?';
    }
}

// ========== AI DESIGN LAB ========== //
function initializeDesignLab() {
    console.log('🎨 Design Lab Initialized');
    
    const designTools = [
        { id: 'logo', name: 'Logo Designer', icon: '🎯' },
        { id: 'flyer', name: 'Flyer Creator', icon: '📄' },
        { id: 'thumbnail', name: 'Thumbnail Maker', icon: '🖼️' },
        { id: 'card', name: 'Business Card', icon: '💼' },
        { id: 'album', name: 'Album Cover', icon: '🎵' },
        { id: 'mockup', name: 'UI/UX Mockup', icon: '📱' },
        { id: 'brand', name: 'Brand Kit', icon: '🏷️' },
        { id: 'sticker', name: 'Sticker Maker', icon: '😊' },
        { id: '3dtext', name: '3D Text', icon: '🔤' },
        { id: 'cartoon', name: 'Cartoon Portrait', icon: '🎭' },
        { id: 'bgremove', name: 'BG Removal', icon: '🖌️' },
        { id: 'palette', name: 'Color Palette', icon: '🎨' }
    ];
    
    return designTools;
}

function selectDesignTool(toolId) {
    console.log(`Selected tool: ${toolId}`);
    showNotification(`🎨 ${toolId} tool activated! Start creating...`, 'success');
}

// ========== AI ANIMATION STUDIO ========== //
function generateAnimation(prompt) {
    if (!prompt || prompt.trim() === '') {
        showNotification('❌ Please enter an animation prompt!', 'error');
        return;
    }
    
    showNotification('🎬 Generating your animation... This may take a moment!', 'info');
    
    // Simulate AI animation generation
    setTimeout(() => {
        const animation = {
            id: Date.now(),
            prompt: prompt,
            created: new Date().toISOString(),
            type: 'animation'
        };
        
        AppState.animations.push(animation);
        saveToLocalStorage();
        
        showNotification('✅ Animation generated successfully!', 'success');
        displayAnimationPreview(animation);
    }, 3000);
}

function displayAnimationPreview(animation) {
    const previewArea = document.getElementById('animation-preview');
    if (!previewArea) return;
    
    previewArea.innerHTML = `
        <div class="preview-card">
            <div class="preview-placeholder">
                <i class="fas fa-video" style="font-size: 4rem; color: var(--primary-color);"></i>
                <p>${animation.prompt}</p>
            </div>
            <div class="preview-actions">
                <button class="btn btn-primary" onclick="downloadAnimation('${animation.id}')">
                    <i class="fas fa-download"></i> Download MP4
                </button>
                <button class="btn btn-secondary" onclick="downloadAnimation('${animation.id}', 'gif')">
                    <i class="fas fa-download"></i> Download GIF
                </button>
            </div>
        </div>
    `;
}

// ========== AI VIDEO CREATOR ========== //
function generateVideo(prompt, quality = '1080p') {
    if (!prompt || prompt.trim() === '') {
        showNotification('❌ Please enter a video prompt!', 'error');
        return;
    }
    
    showNotification(`📽️ Creating your ${quality} video... This may take a few minutes!`, 'info');
    
    // Simulate AI video generation
    setTimeout(() => {
        const video = {
            id: Date.now(),
            prompt: prompt,
            quality: quality,
            created: new Date().toISOString(),
            type: 'video'
        };
        
        AppState.videos.push(video);
        saveToLocalStorage();
        
        showNotification('✅ Video created successfully!', 'success');
        displayVideoPreview(video);
    }, 5000);
}

function displayVideoPreview(video) {
    const previewArea = document.getElementById('video-preview');
    if (!previewArea) return;
    
    previewArea.innerHTML = `
        <div class="preview-card">
            <div class="preview-placeholder">
                <i class="fas fa-film" style="font-size: 4rem; color: var(--primary-color);"></i>
                <p>${video.prompt}</p>
                <span class="badge">${video.quality}</span>
            </div>
            <div class="preview-actions">
                <button class="btn btn-primary" onclick="downloadVideo('${video.id}')">
                    <i class="fas fa-download"></i> Download Video
                </button>
                <button class="btn btn-secondary" onclick="shareVideo('${video.id}')">
                    <i class="fas fa-share"></i> Share
                </button>
            </div>
        </div>
    `;
}

// ========== VIDEO DOWNLOADER ========== //
function downloadSocialVideo(url) {
    if (!url || url.trim() === '') {
        showNotification('❌ Please enter a valid video URL!', 'error');
        return;
    }
    
    // Validate URL
    const supportedPlatforms = ['youtube', 'tiktok', 'instagram', 'facebook', 'twitter', 'snapchat', 'pinterest', 'likee', 'reddit'];
    const platform = supportedPlatforms.find(p => url.toLowerCase().includes(p));
    
    if (!platform) {
        showNotification('❌ Unsupported platform! Please use YouTube, TikTok, Instagram, Facebook, Twitter, Snapchat, Pinterest, Likee, or Reddit links.', 'error');
        return;
    }
    
    showNotification(`📥 Downloading from ${platform}...`, 'info');
    
    // Simulate download
    setTimeout(() => {
        showNotification('✅ Video downloaded successfully!', 'success');
        displayDownloadOptions(url, platform);
    }, 2000);
}

function displayDownloadOptions(url, platform) {
    const optionsArea = document.getElementById('download-options');
    if (!optionsArea) return;
    
    optionsArea.innerHTML = `
        <div class="download-card">
            <h4>✅ Download Ready!</h4>
            <p>Platform: ${platform}</p>
            <div class="download-actions">
                <button class="btn btn-primary">
                    <i class="fas fa-video"></i> Download MP4
                </button>
                <button class="btn btn-secondary">
                    <i class="fas fa-music"></i> Extract MP3
                </button>
                <button class="btn btn-gold">
                    <i class="fas fa-magic"></i> AI Clone Video
                </button>
            </div>
        </div>
    `;
}

// ========== PRODUCT CUSTOMIZER ========== //
function initializeProductCustomizer(productType) {
    console.log(`Initializing customizer for: ${productType}`);
    
    const products = {
        'tshirt': { name: 'T-Shirt', colors: ['#FFFFFF', '#000000', '#FF6B9D', '#FFC048', '#00BCD4'] },
        'hoodie': { name: 'Hoodie', colors: ['#FFFFFF', '#000000', '#808080', '#FF6B9D', '#FFC048'] },
        'cap': { name: 'Cap', colors: ['#FFFFFF', '#000000', '#FF0000', '#0000FF', '#FFC048'] },
        'mug': { name: 'Mug', colors: ['#FFFFFF', '#000000', '#FF6B9D', '#FFC048', '#00BCD4'] },
        'pillow': { name: 'Throw Pillow', colors: ['#FFFFFF', '#FF6B9D', '#FFC048', '#00BCD4', '#C44569'] }
    };
    
    const product = products[productType] || products['tshirt'];
    return product;
}

function updateProductColor(color) {
    const preview = document.getElementById('product-preview');
    if (preview) {
        preview.style.backgroundColor = color;
    }
}

function addTextToProduct(text, font = 'Arial', size = '24px') {
    const preview = document.getElementById('product-preview');
    if (!preview) return;
    
    const textElement = document.createElement('div');
    textElement.className = 'product-text';
    textElement.textContent = text;
    textElement.style.cssText = `
        font-family: ${font};
        font-size: ${size};
        color: #333;
        padding: 1rem;
        cursor: move;
    `;
    
    preview.appendChild(textElement);
    makeDraggable(textElement);
}

function makeDraggable(element) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    
    element.onmousedown = dragMouseDown;
    
    function dragMouseDown(e) {
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }
    
    function elementDrag(e) {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        element.style.top = (element.offsetTop - pos2) + "px";
        element.style.left = (element.offsetLeft - pos1) + "px";
    }
    
    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

// ========== NOTIFICATIONS ========== //
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.2);
        z-index: 9999;
        animation: slideInRight 0.3s ease;
        max-width: 350px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// ========== CONTACT FUNCTIONS ========== //
function contactViaWhatsApp() {
    window.open('https://wa.me/2349131103329', '_blank');
}

function contactViaEmail() {
    window.location.href = 'mailto:rasheedatayomide914@gmail.com';
}

function submitContactForm(formData) {
    showNotification('📧 Message sent! We\'ll get back to you soon!', 'success');
    console.log('Contact form submitted:', formData);
}

// ========== LOCAL STORAGE ========== //
function saveToLocalStorage() {
    try {
        localStorage.setItem('ayozy_app_state', JSON.stringify(AppState));
    } catch (e) {
        console.error('Failed to save to localStorage:', e);
    }
}

function loadFromLocalStorage() {
    try {
        const saved = localStorage.getItem('ayozy_app_state');
        if (saved) {
            const parsed = JSON.parse(saved);
            Object.assign(AppState, parsed);
            console.log('App state loaded from localStorage');
        }
    } catch (e) {
        console.error('Failed to load from localStorage:', e);
    }
}

// ========== GALLERY FUNCTIONS ========== //
function loadGallery() {
    const allItems = [...AppState.designs, ...AppState.animations, ...AppState.videos];
    console.log(`Loading gallery with ${allItems.length} items`);
    return allItems;
}

function deleteGalleryItem(id) {
    AppState.designs = AppState.designs.filter(item => item.id != id);
    AppState.animations = AppState.animations.filter(item => item.id != id);
    AppState.videos = AppState.videos.filter(item => item.id != id);
    saveToLocalStorage();
    showNotification('🗑️ Item deleted successfully!', 'success');
}

// ========== EXPORT FUNCTIONS ========== //
function downloadAnimation(id, format = 'mp4') {
    showNotification(`📥 Downloading animation as ${format.toUpperCase()}...`, 'info');
    setTimeout(() => {
        showNotification('✅ Download complete!', 'success');
    }, 1500);
}

function downloadVideo(id) {
    showNotification('📥 Preparing video download...', 'info');
    setTimeout(() => {
        showNotification('✅ Download complete!', 'success');
    }, 1500);
}

function shareVideo(id) {
    showNotification('📤 Opening share options...', 'info');
}

// ========== UTILITY FUNCTIONS ========== //
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// ========== GLOBAL EXPORTS ========== //
window.AyozyStudio = {
    generateAnimation,
    generateVideo,
    downloadSocialVideo,
    selectDesignTool,
    updateProductColor,
    addTextToProduct,
    contactViaWhatsApp,
    contactViaEmail,
    showNotification
};

console.log('✨ Ayozy Graphics Vibes - All systems ready! 🎨');